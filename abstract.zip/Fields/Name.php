<?php
namespace Fields;
class Name extends AbstractField{
    public function __construct(){
        $this->setType('text');
    }
} 